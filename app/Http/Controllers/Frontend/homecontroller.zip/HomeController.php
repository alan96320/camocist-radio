<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use GuzzleHttp\Client;
use Carbon\Carbon;
use App\Models\Timebelt;
/**
 * Class HomeController.
 */
class HomeController extends Controller
{
    /**
     * @return \Illuminate\View\View
     */
    public function index(){ 
        
        return view('frontend.index');
    }

    public function response_883jia(){

    	$client = new Client();
    	$request = $client->request('GET', 'https://np.tritondigital.com/public/nowplaying?mountName=883JIA&numberToFetch=1&eventType=track');
    	
    	$data1 = simplexml_load_string($request->getBody(), 'SimpleXMLElement', LIBXML_NOBLANKS);
        $string = json_encode($data1);
        $data_a = json_decode($string, true);


        $data2 = simplexml_load_string($request->getBody(), 'SimpleXMLElement', LIBXML_NOCDATA | LIBXML_NOBLANKS);
    	$string2 = json_encode($data2);
   		$data_a2 = json_decode($string2, true);

        $title = $data_a2['nowplaying-info']['property'][2];
        

        $data = array();
        $data['title'] = $title;

        if($data_a['nowplaying-info']['property'][3]['@attributes']['name'] == 'track_artist_name'){
        	$artist_name = $data_a2['nowplaying-info']['property'][3];
        }
        else{
        	$artist_name = $data_a2['nowplaying-info']['property'][4];
        }

        $now = Carbon::now('Asia/Singapore');
        $nowTime = $now->hour.':'.$now->minute;

        $today_day = Carbon::now('Asia/Singapore')->format('l');
    	
        $timebelts = Timebelt::where('player_name','883JIA')->where('is_active',1)->where('is_default',0)->get();
        $data = array();
        $data['image'] = '';
        foreach($timebelts as $timebelt){

            $start_time = $timebelt->start_time;
            $end_time   = $timebelt->end_time;  

            // Days 
            $days = $timebelt->days;
            $days_array = explode(',', $days);

            foreach ($days_array as $day) {

            	if($day == $today_day){
            		if(strtotime($nowTime) > strtotime($start_time) && strtotime($nowTime) < strtotime($end_time) )
            		{
		                $image = $timebelt->banner_image;
		                $data['image'] = $image;
                        
		            } 	
            	}		
            }
        }
        if($data['image'] == ''){
        	$timebelt_image = Timebelt::where('player_name','883JIA')->where('is_active',1)->where('is_default',1)->first();
        	$data['default_image'] = $timebelt_image->banner_image;
        }
        $data['title']  = $title;
        $data['artist_name'] = $artist_name;

        $itune_api = 'https://itunes.apple.com/search?term='. $title .'+'.$artist_name.'&country=sg&
	media=music&entity=song&limit=1&lang=en_us&explicit=Yes&version=2';

		$client_itunes = new Client();
    	$request_itunes = $client_itunes->request('GET', $itune_api);
    	
    	$data_itunes = json_decode($request_itunes->getBody(),true);
    	//echo $data1;
    	$data['cover_art'] = '';
    	//foreach ($data_itunes['results'] as $result) {
    		
    		//if(strtoupper($result['trackName']) == $title  && strtoupper($result['artistName'])  == $artist_name){
    		if(count($data_itunes['results']) > 0){
    			$cover_art = $data_itunes['results'][0]['artworkUrl100'];
    			$data['cover_art'] = $cover_art;
			}
    		//}    		
    	//}

		return response()->json($data, 200);
    }

    public function response_883jia_2(){

    	$client = new Client();
    	$request = $client->request('GET', 'https://np.tritondigital.com/public/nowplaying?mountName=JIA_WEBHITS_S01&numberToFetch=1&eventType=track');
    	
        $data1 = simplexml_load_string($request->getBody(), 'SimpleXMLElement', LIBXML_NOBLANKS);
        $string = json_encode($data1);
        $data_a = json_decode($string, true);


        $data2 = simplexml_load_string($request->getBody(), 'SimpleXMLElement', LIBXML_NOCDATA | LIBXML_NOBLANKS);
    	$string2 = json_encode($data2);
   		$data_a2 = json_decode($string2, true);

        $title = $data_a2['nowplaying-info']['property'][2];

        $timebelt_image = Timebelt::where('player_name','883JIA WEBHITS')->where('is_active',1)->where('is_default',1)->first();

        $data = array();
        $data['default_image'] = $timebelt_image->banner_image;

        if($data_a['nowplaying-info']['property'][3]['@attributes']['name'] == 'track_artist_name'){
        	$artist_name = $data_a2['nowplaying-info']['property'][3];
        }
        else{
        	$artist_name = $data_a2['nowplaying-info']['property'][4];
        }

        
        $data['title'] = $title;
        $data['artist_name'] = $artist_name;

        $itune_api = 'https://itunes.apple.com/search?term='. $title .'+'.$artist_name.'&country=sg&
	media=music&entity=song&limit=1&lang=en_us&explicit=Yes&version=2';

		$client_itunes = new Client();
    	$request_itunes = $client_itunes->request('GET', $itune_api);
    	
    	$data_itunes = json_decode($request_itunes->getBody(),true);
    	
    	$data['cover_art'] = '';
    	//foreach ($data_itunes['results'] as $result) {
    		
    		//if(strtoupper($result['trackName']) == $title  && strtoupper($result['artistName'])  == $artist_name){
    			if(count($data_itunes['results']) > 0){
	    			$cover_art = $data_itunes['results'][0]['artworkUrl100'];
	    			$data['cover_art'] = $cover_art;
				}
    		//}    		
    	//}
		return response()->json($data, 200);
    }


    public function response_883jia_3(){

    	$client = new Client();
    	$request = $client->request('GET', 'https://np.tritondigital.com/public/nowplaying?mountName=JIA_KPOP_S01&numberToFetch=1&eventType=track');
    	
    	$data1 = simplexml_load_string($request->getBody(), 'SimpleXMLElement', LIBXML_NOBLANKS);
        $string = json_encode($data1);
        $data_a = json_decode($string, true);


        $data2 = simplexml_load_string($request->getBody(), 'SimpleXMLElement', LIBXML_NOCDATA | LIBXML_NOBLANKS);
    	$string2 = json_encode($data2);
   		$data_a2 = json_decode($string2, true);

        $title = $data_a2['nowplaying-info']['property'][2];
        
      	$timebelt_image = Timebelt::where('player_name','883JIA KPOP')->where('is_active',1)->where('is_default',1)->first();

        $data = array();
        $data['default_image'] = $timebelt_image->banner_image;

        if($data_a['nowplaying-info']['property'][3]['@attributes']['name'] == 'track_artist_name'){
        	$artist_name = $data_a2['nowplaying-info']['property'][3];
        }
        else{
        	$artist_name = $data_a2['nowplaying-info']['property'][4];
        }
        $data['title'] = $title;
        $data['artist_name'] = $artist_name;

        $itune_api = 'https://itunes.apple.com/search?term='. $title .'+'.$artist_name.'&country=sg&
	media=music&entity=song&limit=1&lang=en_us&explicit=Yes&version=2';

		$client_itunes = new Client();
    	$request_itunes = $client_itunes->request('GET', $itune_api);
    	
    	$data_itunes = json_decode($request_itunes->getBody(),true);
    	
    	$data['cover_art'] = '';
    	//foreach ($data_itunes['results'] as $result) {
    		
    		//if(strtoupper($result['trackName']) == $title  && strtoupper($result['artistName'])  == $artist_name){
    			if(count($data_itunes['results']) > 0){
	    			$cover_art = $data_itunes['results'][0]['artworkUrl100'];
	    			$data['cover_art'] = $cover_art;
				}
    		//}    		
    	//}
        return response()->json($data, 200);
    }


    public function response_power_98(){

    	$client = new Client();
    	$request = $client->request('GET', 'https://np.tritondigital.com/public/nowplaying?mountName=POWER98&numberToFetch=1&eventType=track');

        $data1 = simplexml_load_string($request->getBody(), 'SimpleXMLElement', LIBXML_NOBLANKS);
        $string = json_encode($data1);
        $data_a = json_decode($string, true);


        $data2 = simplexml_load_string($request->getBody(), 'SimpleXMLElement', LIBXML_NOCDATA | LIBXML_NOBLANKS);
    	$string2 = json_encode($data2);
   		$data_a2 = json_decode($string2, true);

        $title = $data_a2['nowplaying-info']['property'][2];
        
        $data = array();
        $data['title'] = $title;

        if($data_a['nowplaying-info']['property'][3]['@attributes']['name'] == 'track_artist_name'){
        	$artist_name = $data_a2['nowplaying-info']['property'][3];
        }
        else{
        	$artist_name = $data_a2['nowplaying-info']['property'][4];
        }

        $now = Carbon::now('Asia/Singapore');
        $nowTime = $now->hour.':'.$now->minute;

        $today_day = Carbon::now('Asia/Singapore')->format('l');

        $timebelts = Timebelt::where('player_name','POWER98')->where('is_active',1)->where('is_default',0)->get();
		       
        $data = array();
        $data['image'] = '';
        foreach($timebelts as $timebelt){

            $start_time = $timebelt->start_time;
            $end_time   = $timebelt->end_time;  
            
            // Days 
            $days = $timebelt->days;
            $days_array = explode(',', $days);

            foreach ($days_array as $day) {

            	if($day == $today_day){
            		if(strtotime($nowTime) > strtotime($start_time) && strtotime($nowTime) < strtotime($end_time) )
            		{
		                $image = $timebelt->banner_image;
		                $data['image'] = $image;
		            } 	
            	}		
            }       
        }
        if($data['image'] == ''){
        	$timebelt_image = Timebelt::where('player_name','POWER98')->where('is_active',1)->where('is_default',1)->first();
        	$data['default_image'] = $timebelt_image->banner_image;
        }
        $data['title'] = $title;
        $data['artist_name'] = $artist_name;

        $itune_api = 'https://itunes.apple.com/search?term='. $title .'+'.$artist_name.'&country=sg&
	media=music&entity=song&limit=1&lang=en_us&explicit=Yes&version=2';

		$client_itunes = new Client();
    	$request_itunes = $client_itunes->request('GET', $itune_api);
    	
    	$data_itunes = json_decode($request_itunes->getBody(),true);
    	
    	$data['cover_art'] = '';
    	//foreach ($data_itunes['results'] as $result) {
    		
    		//if(strtoupper($result['trackName']) == $title  && strtoupper($result['artistName'])  == $artist_name){
    			if(count($data_itunes['results']) > 0){
	    			$cover_art = $data_itunes['results'][0]['artworkUrl100'];
	    			$data['cover_art'] = $cover_art;
				}
    		//}    		
    	//}

		return response()->json($data, 200);
    }

     public function response_power_98_hits(){

    	$client = new Client();
    	$request = $client->request('GET', 'https://np.tritondigital.com/public/nowplaying?mountName=POWER98_HITS_S01&numberToFetch=1&eventType=track');
    	
    	$data1 = simplexml_load_string($request->getBody(), 'SimpleXMLElement', LIBXML_NOBLANKS);
        $string = json_encode($data1);
        $data_a = json_decode($string, true);


        $data2 = simplexml_load_string($request->getBody(), 'SimpleXMLElement', LIBXML_NOCDATA | LIBXML_NOBLANKS);
    	$string2 = json_encode($data2);
   		$data_a2 = json_decode($string2, true);

        $title = $data_a2['nowplaying-info']['property'][2];        

        $timebelt_image = Timebelt::where('player_name','POWER98 HITS')->where('is_active',1)->where('is_default',1)->first();

        $data = array();
        $data['default_image'] = $timebelt_image->banner_image;

        if($data_a['nowplaying-info']['property'][3]['@attributes']['name'] == 'track_artist_name'){
        	$artist_name = $data_a2['nowplaying-info']['property'][3];
        }
        else{
        	$artist_name = $data_a2['nowplaying-info']['property'][4];
        }
        $data['title'] = $title;
        $data['artist_name'] = $artist_name;

        $itune_api = 'https://itunes.apple.com/search?term='. $title .'+' . $artist_name .'&country=sg&
	media=music&entity=song&limit=1&lang=en_us&explicit=Yes&version=2';

		$client_itunes = new Client();
    	$request_itunes = $client_itunes->request('GET', $itune_api);
    	
    	$data_itunes = json_decode($request_itunes->getBody(),true);
    	//echo $data1;
    	$data['cover_art'] = '';
    	//foreach ($data_itunes['results'] as $result) {
    		
    		//if(strtoupper($result['trackName']) == $title  && strtoupper($result['artistName'])  == $artist_name){
    			if(count($data_itunes['results']) > 0){
	    			$cover_art = $data_itunes['results'][0]['artworkUrl100'];
	    			$data['cover_art'] = $cover_art;
				}
    		//}    		
    	//}

        return response()->json($data, 200);
    }

     public function response_power_98_ls(){

    	$client = new Client();
    	$request = $client->request('GET', 'https://np.tritondigital.com/public/nowplaying?mountName=POWER98_LOVESONGS_S01&numberToFetch=1&eventType=track');
    	
        $data1 = simplexml_load_string($request->getBody(), 'SimpleXMLElement', LIBXML_NOBLANKS);
        $string = json_encode($data1);
        $data_a = json_decode($string, true);


        $data2 = simplexml_load_string($request->getBody(), 'SimpleXMLElement', LIBXML_NOCDATA | LIBXML_NOBLANKS);
    	$string2 = json_encode($data2);
   		$data_a2 = json_decode($string2, true);

        $title = $data_a2['nowplaying-info']['property'][2];       

        $timebelt_image = Timebelt::where('player_name','POWER98 LOVE SONGS')->where('is_active',1)->where('is_default',1)->first();

        $data = array();
        $data['default_image'] = $timebelt_image->banner_image;

        if($data_a['nowplaying-info']['property'][3]['@attributes']['name'] == 'track_artist_name'){
        	$artist_name = $data_a2['nowplaying-info']['property'][3];
        }
        else{
        	$artist_name = $data_a2['nowplaying-info']['property'][4];
        }
        $data['title'] = $title;
        $data['artist_name'] = $artist_name;

        $itune_api = 'https://itunes.apple.com/search?term='. $title .'+' . $artist_name .'&country=sg&
	media=music&entity=song&limit=1&lang=en_us&explicit=Yes&version=2';

		$client_itunes = new Client();
    	$request_itunes = $client_itunes->request('GET', $itune_api);
    	
    	$data_itunes = json_decode($request_itunes->getBody(),true);
    	
    	$data['cover_art'] = '';
    	//foreach ($data_itunes['results'] as $result) {
    		
    		//if(strtoupper($result['trackName']) == $title  && strtoupper($result['artistName'])  == $artist_name){
    			if(count($data_itunes['results']) > 0){
	    			$cover_art = $data_itunes['results'][0]['artworkUrl100'];
	    			$data['cover_art'] = $cover_art;
				}
    		//}    		
    	//}

        return response()->json($data, 200);
    }


    public function info_883jia(){ 
        
        return view('frontend.883jia');
    }

    public function info_power98(){ 
        
        return view('frontend.power98');
    }

    public function music_drama(){ 
        
        return view('frontend.music_drama');
    }

    public function about_us(){ 

        return view('frontend.about_us');
    }	
}